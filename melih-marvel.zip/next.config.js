/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['i.annihil.us'],
  },
};

module.exports = nextConfig;
